package com.qasymphony.qtestscenario.demo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.lang.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by hoangle on 9/11/2015.
 */
public class CalculatorSteps {
    private Calculator calculator;
    String warningMessage = ""; // Warning message
    List<Number> numberList; // List base number to the power
    List<Integer> actualListResult;  // Actual list result

    @Given("^I have calculator$")
    public void i_have_calculator() throws Throwable {
        calculator = new Calculator();
    }

    @When("^I add (\\d+) and (\\d+)$")
    public void i_add_and(int firstNumber, int secondNumber) throws Throwable {
        calculator.addNumbers(firstNumber, secondNumber);
    }

    @Then("^I should see (\\d+)$")
    public void i_should_see(int expectedResult) throws Throwable {
        assertEquals("Total number displayed wrongly", expectedResult, calculator.getResult());
    }

    private List<Integer> listNumber;
    @Given("^I have list of number$")
    public void i_have_list_of_number(List<Integer> listNumber) throws Throwable {
        this.listNumber = listNumber;
        calculator = new Calculator();
    }

    @When("^I add all number in list$")
    public void i_add_all_number_in_list() throws Throwable {
        calculator.sumAllNumberInList(listNumber);
    }

    @Then("^the result after adding all number in list should be (\\d+)$")
    public void the_result_after_adding_all_number_in_list_should_be(int expectedResult) throws Throwable {
       assertEquals("Total number displayed wrongly", expectedResult, calculator.getResult());
    }

    @When("^I multiply all number in list$")
    public void i_multiply_all_number_in_list() throws Throwable {
        calculator.multiplyAllNumberInList(listNumber);
    }

    @Then("^the result after multiplying all number in list should be (\\d+)$")
    public void the_result_after_multiplication_all_number_in_list_should_be(int expectedResult) throws Throwable {
        assertEquals("Total number displayed wrongly", expectedResult, calculator.getResult());
    }

    // Scenario Outline steps
    @When("^I do (\\w+) for (-?\\d+) and (-?\\d+)$")
    public void i_do_add_for_and(String operation, int firstNum, int secondNum) throws Throwable {
        calculator.calculateTwoNumbersWithOperation(operation, firstNum, secondNum);
    }

    @Then("^I should see proper (-?\\d+)$")
    public void i_should_see_proper(int expectedResult) throws Throwable {
         assertEquals("The result displayed wrongly", expectedResult, calculator.getResult());
    }

    @When("^I square the total of two numbers$")
    public void i_square_the_total_of_two_numbers() throws Throwable {
        calculator.squareNumber(calculator.getResult());
    }

    @When("^I divide the total by zero$")
    public void i_divide_the_total_by_zero() throws Throwable {
        warningMessage = calculator.divideByZero(calculator.getResult());
    }

    @Then("^I should see error message \"([^\"]*)\"$")
    public void i_should_see_error_message(String expectedMessage) throws Throwable {
        assertEquals(expectedMessage, warningMessage);
    }

    @When("^base number to the power$")
    public void base_number_to_the_power(List<Number> table) throws Throwable {
        numberList = table;
        actualListResult = calculateResultAfterPoweringNumber(numberList);
    }

    @Then("^I should see proper following result$")
    public void i_should_see_proper_above_result(List<Integer> expectedList) throws Throwable {
        for(int i = 0; i < expectedList.size(); i++){
            assertEquals("The result displayed wrongly", expectedList.get(i), actualListResult.get(i));
        }
    }

    /**
     * This method used to return number to the power
     * @param numberList contains base number and power number
     * @return List<Integer></> This return result after powering numbers
     */
    public List<Integer> calculateResultAfterPoweringNumber(List<Number> numberList){
        List<Integer> result = new ArrayList<Integer>();
        for (int i = 0; i < numberList.size(); i++) {
            calculator.powerNumber(numberList.get(i).getBase_number(),numberList.get(i).getPower());
            result.add(i,calculator.getResult());
        }
        return result;
    }

    @When("^I do factorial for number$")
    public void i_do_factorial_for_number() throws Throwable {
        actualListResult = new ArrayList<Integer>();
        for(int i = 0; i < listNumber.size(); i++){
            calculator.doFactorial(listNumber.get(i));
            actualListResult.add(i, calculator.getResult());
        }
    }

    @When("^I add character (.*) to calculator$")
    public void i_add_some_character_a(String characters) throws Throwable {
        warningMessage = calculator.validateInput(characters);
    }

    @Then("^I should see the warning message \"([^\"]*)\"$")
    public void i_should_see_the_warning_message(String expectedMessage) throws Throwable {
        assertEquals("Error message does not display properly",expectedMessage,warningMessage);
    }

    @When("^I power the sum of \\(first number and second number\\)$")
    public void i_power_the_sum_of_first_number_and_second_number(Map<String,Integer> table) throws Throwable {
        Map<String,Integer> list = table;
        calculator.addNumbers(list.get("first number"), list.get("second number"));
        calculator.powerNumber(calculator.getResult(),list.get("power"));
    }

}
