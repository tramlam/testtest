package com.qasymphony.qtestscenario.demo;

import java.util.List;

import static java.util.Arrays.asList;

/**
 * Created by hoangle on 9/11/2015.
 */
public class Calculator {
    private int result = 0;
    List<Integer> numbers;

    public int getResult() {
        return result;
    }

    /**
     * This method is used to add two integers.
     * @param firstNum the first number is defined by integer number
     * @param secondNum the second number is defined by integer number
     */
    public void addNumbers(int firstNum, int secondNum){
        result = firstNum + secondNum;
    }

    /**
     * This method is used to calculate subtraction between two integers.
     * The first number minus second number.
     * @param firstNum the first number is defined by integer number
     * @param secondNum the second number is defined by integer number
     */
    public void subtractNumbers(int firstNum, int secondNum){
        result = firstNum - secondNum;
    }

    public void multiplyNumbers(int firstNum, int secondNum){
        result = firstNum * secondNum;
    }

    public void divideNumbers(int firstNum, int secondNum){
        result = firstNum / secondNum;
    }

    /**
     * This method is used to add all numbers in list.
     * @param numbers list integer numbers
     */
    public void sumAllNumberInList(List<Integer> numbers){
        for(int i : numbers){
            result += i;
        }
    }

    /**
     * This method is used to multiply all numbers in list.
     * @param numbers list integer numbers
     */
    public void multiplyAllNumberInList(List<Integer> numbers){
        if(result == 0){
            result = 1;
        }
        for(int i : numbers){
            result *= i;
        }
    }

    /**
     * This method is used  to calculate two numbers based on specific operation
     * @param operation string defines operation that includes "add", "subtract", "multiply", "divide"
     * @param firstNum the first number is defined by integer
     * @param secondNum the second number is defined by integer
     */
    public void calculateTwoNumbersWithOperation(String operation, int firstNum, int secondNum){
        if(operation.equalsIgnoreCase("add")){
            addNumbers(firstNum,secondNum);
        } else if (operation.equalsIgnoreCase("subtract")){
            subtractNumbers(firstNum, secondNum);
        } else if (operation.equalsIgnoreCase("multiply")){
            multiplyNumbers(firstNum,secondNum);
        } else if (operation.equalsIgnoreCase("divide")){
            divideNumbers(firstNum,secondNum);
        } else {
            try {
                 throw new IllegalArgumentException("There is no operation \'" + operation +"\'");
            } catch(IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    /**
     * This method is used to square the number
     * @param number the number is squared
     */
    public void squareNumber(int number){
        Double tempResult = Math.pow(number,2);
        result = tempResult.intValue();
    }

    /**
     * This method is used to divide number by zero
     * @param num the number is divided by zero
     * @return
     */
    public String divideByZero(int num){
        try {
            int result = num/0;
        } catch (ArithmeticException e){
            return "Cannot divide by zero";
        }
        return "User can divide number by zero";
    }

    /**
     * This method is used to number to the specific power
     * @param baseNumber number to be powered
     * @param power the exponent number
     */
    public void powerNumber(int baseNumber, int power){
        Double tempResult = Math.pow(baseNumber,power);
        result = tempResult.intValue();
    }

    /**
     * This method is used to calculate factorial of number
     * @param number number to be factorial
     * @return result after doing factorial
     */
    public int doFactorial(int number){
        if(number == 0 ) result = 1;
        else {
            result = number * doFactorial(number -1);
        }
        return result;
    }

    /**
     * This method is used to validate input.
     * If input is not integer, method returns warning message.
     * @param input param string user input
     * @return string after input validation
     */
    public String validateInput(String input){
        try {
            Integer.parseInt(input);
            return "";
        } catch (NumberFormatException e){
            return "You have inputted invalid number";
        }
    }

}
