package com.qasymphony.qtestscenario.demo;

/**
 * Created by hoangle on 9/15/2015.
 */
public class Number {
    private int baseNumber;
    private int power;

    public Number(int base_number, int power) {
        this.baseNumber = base_number;
        this.power = power;
    }

    /**
     *
     * @return base number
     */
    public int getBase_number() {
        return baseNumber;
    }

    /**
     *
     * @return power number
     */
    public int getPower() {
        return power;
    }
}
